/**
 * Enum - category of fruit.
 * As an enum, contains both an index and a string.
 * The string here is the file name, so each category can get the right image associated to it.
 */
public enum FruitCategory {
  APPLE("apple.png", 0),
  ORANGE("orange.png", 1), 
  PEACH("peach.png", 2),
  PEAR("pear.png", 3),
  STRAWBERRY("strawberry.png", 4),
  BLUEBERRY("blueberry.png", 5),
  LEMON("lemon.png", 6),
  RASPBERRY("raspberry.png", 7),
  BANANA("banana.png", 8);
  
  private String stringfruit;
  private int intfruit;

  private FruitCategory(String _sfruit, int _ifruit) {
    stringfruit = _sfruit;
    intfruit = _ifruit;
  }

  public String toString() {
    return stringfruit;
  }
}

