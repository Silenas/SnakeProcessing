/**
 * Direction enum class
 * An enumeration is a very convenient way to have a list of values that are part
 * of a single set: here 4 directions.
 * The key use for this structure is the integer which allows to "switch/case" the directions
 * that come in the process
 */
public enum Direction {
  WEST("West", 0),
  NORTH("North", 1), 
  EAST("East", 2), 
  SOUTH("South", 3);

  private String stringvalue;
  private int value;
  
  private Direction(String _string, int _value) {
    stringvalue = _string;
    value = _value;
  }
  
  @Override
  public String toString() {
    return stringvalue;
  }
};

