import processing.core.PApplet;
import java.lang.Math;

/**
 * Utils is whatever extra tool is necessary
 * Mainly - we got math operation here in one place
 * Randomisation on interval is being applied where interval is [min, max]
 */
public class Utils {
  /**
   * Method to get a random value witin an interval with same probability for each value
   */
  public static int getRandomRangeValue(int min, int max) {
    int v = min + (int)(Math.random() * (max - min + 1));
    return v;
  }

  /**
   * Random X in a given app world
   */
  public static int getRandomX(PApplet app, int margin) {
    return getRandomRangeValue(0+margin, app.width-margin);
  }

  /**
   * Random Y in a given app world
   */
  public static int getRandomY(PApplet app, int margin) {
    return getRandomRangeValue(0+margin, app.height-margin);
  }

  public static FruitCategory getRandomFruitCategory() {
    int cat = Utils.getRandomRangeValue(0, 8);
    return FruitCategory.values()[cat];
  }

  /**
   * This is to keep the import Math in one place only
   */
  public static int max(int a, int b) {
    return Math.max(a, b);
  }
}
