This source directory contains source for the BoxWrap2d library for Processing (http://www.processing.org).  For the most part BoxWrap2d will not be very useful outside of Processing; it is included in the main JBox2d development line merely to make it easier to keep things in sync.

Javadocs for BoxWrap2d are in the doc directory.  See the Physics class Javadocs for instructions on how to use the library.

BoxWrap2d requires Java 1.5 to run, which means that a recent (June 2008 or later) version of Processing is necessary.  If you absolutely need 1.4 support, you can use Retroweaver to weave 1.4 compatible bytecode, but in most cases this should be unnecessary.