import java.util.ArrayList;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;
import processing.core.PApplet;
import processing.event.MouseEvent;

/**
 * Snake class - the snake itself and its components
 * In this version - for Android - please note the "static" keyword for the class.
 * This is because in a PDE, the class is nested, and we need this class to be a top class
 * to reuse it and do the register method.
 * A snake is a list of rectangles (units). Since they are all the same, the concept is pretty simple.
 * We do not need to move the whole snake: a new unit appears as the head, and the last unit disappear.
 * It looks like the whole snake got forward.
 * The only things left to manage are:
 * - length or number of units the snake is made of (helps also with the status: size = 0 = dead)
 * - direction: where the head (new unit) is going to appear.
 */
public class Snake {
  public static final int START_LENGTH = 3; // starting length
  public static final int THICKNESS = 22;

  // App details
  private PApplet parent = null;

  // Drawing details
  private final int R = 210, G = 120, B = 30;
  private int thickness = THICKNESS;
  private Direction dir = Direction.WEST;
  private ArrayList<Point> parts;
  private int growth = 0;

  /**
   * Constructor: important because of register Method "draw" which allows the app to call draw below
   */
  public Snake(PApplet app, int _posx, int _posy) {
    // setup parent
    parent = app;
    parent.registerMethod("draw", this);
    // build body
    parts = new ArrayList<Point>();
    for (int index=0; index < START_LENGTH; index++) {
      Point p = new Point(_posx + index * thickness, _posy);
      parts.add(p);
    }
  }

  public Snake(PApplet app, int _posx, int _posy, int _thickness, Direction _dir) {
    this(app, _posx, _posy);
    thickness = _thickness;
    setDirection(_dir);
  }

  /**
   * moving is simple: head goes to the right direction
   * the tail follow - everything else remains the same
   */
  public void moveBody() throws Exception {
    if(parts.size() == 0)
      return;
    Point head = parts.get(0);
    int posx = head.x, posy = head.y;
    Point newHead;
    switch(dir) {
    case WEST:
      newHead = new Point(posx - thickness, posy);
      break;
    case NORTH:
      newHead = new Point(posx, posy - thickness);
      break;
    case EAST:
      newHead = new Point(posx + thickness, posy);
      break;
    case SOUTH:
      newHead = new Point(posx, posy + thickness);
      break;
    default:
      throw new Exception("Direction error");
    }
    parts.add(0, newHead); // add one to front
    /* now, manage growth according to length:
     * That means, do not delete anything while the snake is growing
     */
    if (growth > 0) {
      growth--;
    } 
    else {
      parts.remove(parts.size() - 1); // remove last
    }
  }

  /**
   * A status management based on length
   */
  public boolean isDead() {
    return parts.size() < 1 ;
  }

  /**
   * Collision detection: given a point, and the way each part of the snake 
   * is drawn, we just have to get 2 rectangles and use the intersect method (shape collision algo)
   * provided point is origin of item, length parameter is size of item
   * for instance: fruit = (coordinate, size)
   */
  public boolean pointOverlap(Point p, int length, boolean headonly) {
    for(Point sp : parts) {
      Rectangle rec1 = new Rectangle(sp, new Dimension(thickness, thickness));
      Rectangle rec2 = new Rectangle(p, new Dimension(length, length));
      if(rec1.intersects(rec2)) {
        return true;
      }
      if(headonly) {
        break;
      }
    }
    return false;
  }

  // some getters / setters
  public void setThickness(int _thickness) throws Exception {
    if (_thickness < 2) {
      throw new Exception("invalid snake thickness");
    }
    thickness = _thickness;
  }

  public int getThickness() {
    return thickness;
  }

  /**
   * Probably a bad name for this method: this is more a reduce length method.
   * Intended to provide cases when the snake gets smaller
   */
  public void setLength(int _snakelength) throws Exception {
    if ((_snakelength >= parts.size()) || (_snakelength < 0)) {
      throw new Exception("invalid snake length");
    }
    for (int index = parts.size(); index > (_snakelength - 1); index--) {
      parts.remove(index);
    }
  }

  public int getLength() {
    return parts.size();
  }

  public void setDirection(Direction _dir) {
    dir = _dir;
  }

  public Direction getDirection() {
    return dir;
  }

  /**
   * Drawing method: called at each frame draw by the parent app.
   * Considering the snake construction and movement, it is fairly
   * simple to spot a collision between head and body using only the head origin point.
   * Such a collision will instantly cause death using "stop"
   */
  public void draw() throws Exception {
    if(parts.size() > 0) {
      moveBody();
      parent.fill(R, G, B);
      // draw and check collision with body
      Point head = getHead();
      if((head.x < 1)
            || (head.x + thickness > parent.width - 1)
            || (head.y < 1)
            || (head.y + thickness > parent.height - 1)) {
         stop();
      }
      for(int index = 0; index < parts.size(); index++) {
        int x = parts.get(index).x, y = parts.get(index).y;
        if(index > 0 && head.x == x && head.y == y) {
          // collision:
          stop();
        }
        // drawing each unit: please note the "rounded" part: last argument = 10
        parent.rect(x, y, thickness, thickness, 10);
      }
    }
  }

  public Point getHead() {
    return parts.get(0);
  }

  public void stop() {
    parts.clear();
  }

  public void snakeGrowth() {
    growth++;
  }

  public void snakeGrowth(int change) {
    growth += change;
  }

  /**
   * Basic direction change method. Selected Direction is possible only in specific
   * cases
   */

  public void goUp() {
    if ((dir == Direction.EAST) || (dir == Direction.WEST))
      setDirection(Direction.NORTH);
  }

  public void goDown() {
    if ((dir == Direction.EAST) || (dir == Direction.WEST))
      setDirection(Direction.SOUTH);
  }

  public void goLeft() {
    if ((dir == Direction.SOUTH) || (dir == Direction.NORTH))
      setDirection(Direction.WEST);
  }

  public void goRight() {
    if ((dir == Direction.SOUTH) || (dir == Direction.NORTH))
      setDirection(Direction.EAST);
  }
}
