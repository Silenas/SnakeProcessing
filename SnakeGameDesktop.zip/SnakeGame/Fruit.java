import java.util.Arrays;
import java.awt.Point;
import java.lang.Math;
import processing.core.PApplet;
import processing.core.PImage;

/**
 * Fruit class - food for snake
 * A fruit is basically a coordinate which gets a category assigned.
 * The category decide which image should be given to the fruit
 * The interesting part is that this class is also related to the parent class, the applet app.
 * This allows the use of Fruit.draw() method. The method will
 * see the "registerMethod" call within the constructor
 */
public class Fruit {
  public static final int FRUITSIZE = 30;
  
  public Point coord; // position of the fruit
  public FruitCategory cat;
  private PApplet parent = null;
  private PImage img;

  public Fruit(PApplet _app, Point _p, PImage _img, FruitCategory _cat) {
    parent = _app;
    parent.registerMethod("draw", this);
    parent.registerMethod("clear", this);
    cat = _cat;
    img = _img;
    coord = _p;
  }

  public Fruit(PApplet _app, PImage _img, Point _p) {
    this(_app, _p, _img, Utils.getRandomFruitCategory());
  }

  public Fruit(PApplet _app, Point _p) {
    this(_app, _p, null, Utils.getRandomFruitCategory());
  }

  public void setImage(PImage _img) {
    img = _img;
  }

  /**
   * Called automatically: just place an image at fruit coordinate
   */
  public void draw() throws Exception {
    parent.image(img, coord.x, coord.y, FRUITSIZE, FRUITSIZE);
  }

  /**
   * Index is the ordinal of the fruit category. Since FruitCategory is an enum, it has
   * a position integer associated to each values. This is available from ordinal.
   * Interesting later to associate arrays and enum values
   */
  public int getIndex() {
    return cat.ordinal();
  }
  
  /**
   * Since the category has 1 to 9 items - the bonus from fruit will be 1, 2 or 3
   */
  public int getBonus() {
    return Utils.max(1, (int) cat.ordinal() / 3);
  }
  
  public void clear() {
    img = null;
    parent.unregisterMethod("draw", this);
    parent.unregisterMethod("clear", this);
    parent = null;
  }
}
